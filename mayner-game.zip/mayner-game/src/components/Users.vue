<template>
	<div>
		<p>{{ Users }}</p>
	</div>
</template>

<script>

export default {
	data(){
		return{
			Users: 'Useerssssss!'
		}
	}
}
</script>

<style>

</style>