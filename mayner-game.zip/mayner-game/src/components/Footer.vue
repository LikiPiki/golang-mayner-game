<template>
	<footer>
		<p>{{ footerTitle }}</p>
	</footer>
</template>

<script>

export default {
	data(){
		return{
			footerTitle: 'Footer content of my web-app'
		}
	}
}
</script>

<style>

</style>